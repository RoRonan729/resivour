#!/usr/bin/env python3
"""Build the Resivour resource pack: zip src/ -> dist/resivour-pack.zip, write dist/sha1.txt.
Deterministic (sorted names, fixed timestamps) so the SHA only changes when content does.
Also draws the placeholder badge texture if it is missing (no Pillow needed)."""
import hashlib, json, os, struct, sys, zipfile, zlib

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(ROOT, "src")
DIST = os.path.join(ROOT, "dist")
ZIP = os.path.join(DIST, "resivour-pack.zip")
BADGE = os.path.join(SRC, "assets", "resivour", "textures", "item", "badge.png")

def png(width, height, pixels):
    """pixels: list of rows, each a list of (r,g,b,a)."""
    raw = b"".join(b"\x00" + b"".join(struct.pack("4B", *p) for p in row) for row in pixels)
    def chunk(tag, data):
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xffffffff)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))

TEX_DIR = os.path.join(SRC, "assets", "resivour", "textures", "item")
CLEAR = (0, 0, 0, 0)

def paint(name, fn):
    """Write 16x16 textures/item/<name>.png from fn(x, y) -> rgba or None, only if the file is missing (real art wins)."""
    path = os.path.join(TEX_DIR, name + ".png")
    if os.path.exists(path):
        return
    rows = [[(fn(x, y) or CLEAR) for x in range(16)] for y in range(16)]
    os.makedirs(TEX_DIR, exist_ok=True)
    with open(path, "wb") as f:
        f.write(png(16, 16, rows))

def badge(x, y):
    gold, dark, star = (212, 175, 55, 255), (90, 70, 20, 255), (255, 255, 230, 255)
    if x in (0, 15) or y in (0, 15):
        return dark
    if (abs(x - 7.5) + abs(y - 7.5)) < 4 and (x + y) % 2 == 0:
        return star
    return gold

def bandage(x, y):
    # a rolled white bandage, slight diagonal, red cross in the middle
    white, shade, red = (240, 236, 224, 255), (200, 194, 178, 255), (200, 40, 40, 255)
    if 3 <= x <= 12 and 4 <= y <= 11:
        if (6 <= x <= 9 and 6 <= y <= 9) and (x in (7, 8) or y in (7, 8)):
            return red
        return shade if (x + y) % 5 == 0 else white
    return None

def medkit(x, y):
    # red case with a white cross and a dark handle
    red, dark, white = (190, 30, 30, 255), (70, 20, 20, 255), (245, 245, 245, 255)
    if 6 <= x <= 9 and y == 2:
        return dark
    if 2 <= x <= 13 and 3 <= y <= 13:
        if x in (2, 13) or y in (3, 13):
            return dark
        if (7 <= x <= 8 and 5 <= y <= 11) or (5 <= x <= 10 and 7 <= y <= 9):
            return white
        return red
    return None

def defibrillator(x, y):
    # grey unit, green screen, yellow bolt, two paddle wires
    grey, dark, screen, bolt, wire = (120, 125, 130, 255), (50, 52, 56, 255), (40, 160, 90, 255), (250, 210, 40, 255), (30, 30, 30, 255)
    if 2 <= x <= 13 and 4 <= y <= 13:
        if x in (2, 13) or y in (4, 13):
            return dark
        if 4 <= x <= 8 and 6 <= y <= 9:
            return screen
        if (x, y) in [(10, 6), (10, 7), (9, 8), (10, 8), (11, 8), (10, 9), (10, 10), (9, 11)]:
            return bolt
        return grey
    if y in (1, 2, 3) and x in (4, 11):
        return wire
    return None

GUN_SHAPES = {
    # name: (barrel_len, barrel_y, grip_x, grip_h, stock, accent)
    "pistol":   (7, 6, 5, 5, False, (40, 40, 44, 255)),
    "revolver": (8, 6, 5, 5, False, (90, 70, 50, 255)),
    "shotgun":  (13, 7, 4, 4, True, (110, 70, 40, 255)),
    "smg":      (9, 6, 6, 6, False, (30, 30, 34, 255)),
    "rifle":    (13, 6, 5, 5, True, (70, 60, 50, 255)),
    "sniper":   (14, 5, 4, 4, True, (50, 55, 60, 255)),
    "taser":    (6, 6, 5, 5, False, (240, 200, 40, 255)),
}

def gun(name):
    barrel_len, by, gx, gh, stock, accent = GUN_SHAPES[name]
    steel, dark = (120, 124, 130, 255), (35, 36, 40, 255)
    def fn(x, y):
        # barrel: from (15-barrel_len, by) to (15, by+1)
        if 15 - barrel_len <= x <= 15 and by <= y <= by + 1:
            return steel if y == by else dark
        # body block under the barrel
        if 15 - barrel_len + 1 <= x <= 15 - barrel_len + 5 and by + 2 <= y <= by + 3:
            return accent
        # grip
        if gx <= x <= gx + 1 and by + 3 <= y <= by + 3 + gh:
            return dark
        # stock for long guns
        if stock and 1 <= x <= 15 - barrel_len + 1 and by + 1 <= y <= by + 4:
            return accent
        # sight
        if x == 15 - barrel_len + 1 and y == by - 1:
            return dark
        return None
    return fn

AMMO_COLORS = {"pistol": (200, 170, 60, 255), "rifle": (170, 120, 50, 255), "shell": (200, 50, 50, 255), "cell": (60, 160, 220, 255)}

def ammo(kind):
    col = AMMO_COLORS[kind]
    box, edge = (90, 80, 60, 255), (50, 45, 35, 255)
    def fn(x, y):
        if 3 <= x <= 12 and 5 <= y <= 13:
            if x in (3, 12) or y in (5, 13):
                return edge
            if 5 <= x <= 10 and 7 <= y <= 11 and (x % 2 == 1):
                return col
            return box
        return None
    return fn

DRUG_COLORS = {"rush": (230, 60, 60, 255), "iron": (120, 120, 140, 255), "owleye": (90, 200, 120, 255)}

def drug(kind):
    col = DRUG_COLORS[kind]
    glass, cap = (210, 230, 240, 160), (60, 50, 40, 255)
    def fn(x, y):
        if 6 <= x <= 9 and 1 <= y <= 3:
            return cap
        if 4 <= x <= 11 and 4 <= y <= 14:
            if x in (4, 11) or y == 14:
                return glass
            if y >= 8:
                return col
            return glass
        return None
    return fn

def handcuffs(x, y):
    steel, dark = (170, 175, 185, 255), (70, 72, 80, 255)
    # two rings joined by a short chain
    for cx in (4, 11):
        d = ((x - cx) ** 2 + (y - 8) ** 2) ** 0.5
        if 2.2 <= d <= 3.4:
            return steel if (x + y) % 3 else dark
    if 7 <= x <= 8 and y in (7, 8, 9) and (x + y) % 2 == 0:
        return dark
    return None

def vehicle_key(x, y):
    gold, dark, fob = (220, 180, 60, 255), (90, 70, 20, 255), (40, 40, 48, 255)
    d = ((x - 5) ** 2 + (y - 5) ** 2) ** 0.5
    if 1.6 <= d <= 3.0:
        return gold
    if 7 <= x <= 13 and 10 <= y <= 11:
        return gold if x < 11 or y == 10 else dark
    if 6 <= x <= 12 and 6 <= y <= 9 and (x - 6) == (y - 6):
        return gold
    if 10 <= x <= 13 and 1 <= y <= 4:
        return fob
    return None

def radar(x, y):
    body, screen, dot, grip = (60, 62, 70, 255), (30, 120, 70, 255), (120, 240, 120, 255), (30, 30, 34, 255)
    if 2 <= x <= 13 and 2 <= y <= 8:
        if 3 <= x <= 12 and 3 <= y <= 7:
            return dot if (x, y) in [(5, 5), (8, 4), (10, 6)] else screen
        return body
    if 6 <= x <= 9 and 9 <= y <= 14:
        return grip
    return None

# ---- 3D vehicle models: cuboids textured from a 16-cell colour palette ----
PALETTE = [
    (200, 40, 40, 255),    # 0 red
    (40, 80, 200, 255),    # 1 blue
    (240, 240, 240, 255),  # 2 white
    (30, 30, 34, 255),     # 3 black
    (120, 124, 130, 255),  # 4 grey
    (90, 160, 220, 180),   # 5 glass (translucent)
    (250, 210, 40, 255),   # 6 yellow
    (60, 60, 66, 255),     # 7 dark grey
    (180, 60, 60, 255),    # 8 dark red
    (80, 110, 140, 255),   # 9 steel blue
    (40, 40, 40, 255),     # 10 tyre
    (255, 180, 60, 255),   # 11 orange light
    (120, 80, 50, 255),    # 12 wood
    (200, 200, 210, 255),  # 13 silver
    (20, 90, 40, 255),     # 14 green
    (255, 255, 255, 0),    # 15 clear
]

def palette_png():
    """A 16x16 texture where cell (i % 4, i // 4) is palette colour i (each cell 4x4 px)."""
    path = os.path.join(TEX_DIR, "palette.png")
    rows = []
    for y in range(16):
        row = []
        for x in range(16):
            row.append(PALETTE[(y // 4) * 4 + (x // 4)])
        rows.append(row)
    os.makedirs(TEX_DIR, exist_ok=True)
    with open(path, "wb") as f:
        f.write(png(16, 16, rows))

def uv(colour):
    cx, cy = (colour % 4) * 4, (colour // 4) * 4
    return [cx + 1, cy + 1, cx + 3, cy + 3]

def box(frm, to, colour, top=None, front=None):
    faces = {}
    for face in ("north", "south", "east", "west", "up", "down"):
        c = colour
        if face == "up" and top is not None:
            c = top
        if face in ("north", "south") and front is not None:
            c = front
        faces[face] = {"uv": uv(c), "texture": "#p"}
    return {"from": frm, "to": to, "faces": faces}

def wheels(x0, x1, zs, r=3, y=0):
    out = []
    for z in zs:
        for x in (x0, x1):
            out.append(box([x - 1, y, z - r], [x + 1, y + 2 * r, z + r], 10))
    return out

def cuboid_model(name, elements, scale=1.0):
    """Write models/item/<name>.json. Model space is the 16-unit block; vehicles are drawn 1 block = 16 units and
    the display scale in the plugin stretches them. Elements may use coordinates from -16 to 32."""
    model = {
        "texture_size": [16, 16],
        "textures": {"p": "resivour:item/palette", "particle": "resivour:item/palette"},
        "elements": elements,
        "display": {"fixed": {"rotation": [0, 0, 0], "translation": [0, 0, 0], "scale": [scale, scale, scale]}},
    }
    path = os.path.join(SRC, "assets", "resivour", "models", "item", name + ".json")
    with open(path, "w", newline="\n") as f:
        json.dump(model, f, indent=1)
    with open(os.path.join(SRC, "assets", "resivour", "items", name + ".json"), "w", newline="\n") as f:
        f.write('{ "model": { "type": "minecraft:model", "model": "resivour:item/' + name + '" } }\n')

def car(body, roof, glass=5, light=None, stripe=None, length=28, width=14, van=False):
    """A sedan or van centred on x=8, running along z. Units: 16 = one block."""
    hz0, hz1 = 8 - length // 2, 8 + length // 2
    els = []
    # chassis
    els.append(box([8 - width // 2, 3, hz0], [8 + width // 2, 8, hz1], body, top=body))
    # cabin
    cz0 = hz0 + (2 if van else 7)
    cz1 = hz1 - (2 if van else 6)
    els.append(box([8 - width // 2 + 1, 8, cz0], [8 + width // 2 - 1, 14 if van else 13, cz1], roof if not stripe else stripe, top=roof))
    # windows
    els.append(box([8 - width // 2 + 1.01, 9, cz0 - 0.5], [8 + width // 2 - 1.01, 12, cz0 + 0.5], glass))
    els.append(box([8 - width // 2 + 1.01, 9, cz1 - 0.5], [8 + width // 2 - 1.01, 12, cz1 + 0.5], glass))
    els.append(box([8 - width // 2 + 0.6, 9, cz0 + 1], [8 - width // 2 + 1.4, 12, cz1 - 1], glass))
    els.append(box([8 + width // 2 - 1.4, 9, cz0 + 1], [8 + width // 2 - 0.6, 12, cz1 - 1], glass))
    # lights
    els.append(box([8 - width // 2 + 1, 5, hz1 - 0.5], [8 - width // 2 + 3, 7, hz1 + 0.5], 6))
    els.append(box([8 + width // 2 - 3, 5, hz1 - 0.5], [8 + width // 2 - 1, 7, hz1 + 0.5], 6))
    els.append(box([8 - width // 2 + 1, 5, hz0 - 0.5], [8 - width // 2 + 3, 7, hz0 + 0.5], 0))
    els.append(box([8 + width // 2 - 3, 5, hz0 - 0.5], [8 + width // 2 - 1, 7, hz0 + 0.5], 0))
    if light:
        els.append(box([5, 13 if not van else 14, 6], [11, 15 if not van else 16, 10], light))
    els += wheels(8 - width // 2, 8 + width // 2, (hz0 + 5, hz1 - 5))
    return els

def firetruck():
    els = []
    els.append(box([0, 3, -8], [16, 9, 24], 0, top=0))             # chassis
    els.append(box([1, 9, 14], [15, 16, 23], 0, top=0))            # cab
    els.append(box([1.01, 11, 22.5], [14.99, 14, 23.5], 5))         # windscreen
    els.append(box([1, 9, -7], [15, 15, 12], 8, top=13))            # body with silver roof
    els.append(box([3, 15, -6], [13, 17, 10], 13))                  # ladder bed
    els.append(box([5, 16, 15], [11, 18, 19], 1))                   # blue light
    els.append(box([2, 5, 23.5], [6, 7, 24.5], 6)); els.append(box([10, 5, 23.5], [14, 7, 24.5], 6))
    els += wheels(0, 16, (-3, 18), r=3)
    return els

def speedboat():
    els = []
    els.append(box([3, 2, -10], [13, 6, 14], 2, top=12))            # hull, wooden deck
    els.append(box([4, 6, -9], [12, 7, 2], 1))                      # blue stripe deck
    els.append(box([5, 3, 14], [11, 6, 20], 2))                     # bow
    els.append(box([4, 7, 3], [12, 11, 6], 5))                      # windscreen
    els.append(box([6, 2, -14], [10, 5, -10], 7))                   # engine
    return els

def draw_vehicle_models():
    palette_png()
    cuboid_model("vehicle_sedan", car(1, 9))                       # blue sedan, steel-blue roof
    cuboid_model("vehicle_van", car(4, 7, length=30, width=14, van=True))
    cuboid_model("vehicle_police", car(3, 2, light=1, stripe=2))   # black and white, blue light
    cuboid_model("vehicle_ambulance", car(2, 2, light=0, stripe=0, length=30, van=True))
    cuboid_model("vehicle_firetruck", firetruck())
    cuboid_model("vehicle_speedboat", speedboat())

def draw_placeholders():
    for name, fn in (("badge", badge), ("bandage", bandage), ("medkit", medkit), ("defibrillator", defibrillator)):
        paint(name, fn)
    for g in GUN_SHAPES:
        paint("gun_" + g, gun(g))
    for a in AMMO_COLORS:
        paint("ammo_" + a, ammo(a))
    for d in DRUG_COLORS:
        paint("drug_" + d, drug(d))
    paint("handcuffs", handcuffs)
    paint("vehicle_key", vehicle_key)
    paint("radar", radar)
    draw_vehicle_models()

def main():
    draw_placeholders()
    os.makedirs(DIST, exist_ok=True)
    files = []
    for dirpath, _, names in os.walk(SRC):
        for n in names:
            full = os.path.join(dirpath, n)
            files.append((os.path.relpath(full, SRC).replace(os.sep, "/"), full))
    files.sort()
    with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
        for arc, full in files:
            info = zipfile.ZipInfo(arc, date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            with open(full, "rb") as f:
                z.writestr(info, f.read())
    sha = hashlib.sha1(open(ZIP, "rb").read()).hexdigest()
    with open(os.path.join(DIST, "sha1.txt"), "w") as f:
        f.write(sha + "\n")
    print(f"{ZIP}  {os.path.getsize(ZIP)} bytes  {len(files)} files")
    print("sha1:", sha)
    print("server.properties:")
    print("  resource-pack=https://raw.githubusercontent.com/RoRonan729/resivour-pack/main/dist/resivour-pack.zip")
    print(f"  resource-pack-sha1={sha}")
    print("  require-resource-pack=true")
    return 0

if __name__ == "__main__":
    sys.exit(main())
