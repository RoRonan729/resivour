# Resivour resource pack

Custom item models, textures and sounds for the Resivour roleplay server (Paper 26.3, resource format 97).
Vanilla clients get it automatically from the server's join prompt; nothing to install.

## Build
```
python build.py
```
Zips `src/` into `dist/resivour-pack.zip` (deterministic) and writes `dist/sha1.txt`. Commit `dist/` too: the
server downloads the zip straight from this repo.

## server.properties
```
resource-pack=https://raw.githubusercontent.com/RoRonan729/resivour-pack/main/dist/resivour-pack.zip
resource-pack-sha1=<contents of dist/sha1.txt>
resource-pack-prompt=Resivour needs this pack for guns, cars and gear.
require-resource-pack=true
```
After every pack change: run the build, commit, push, and update `resource-pack-sha1`.

## Proof item
`/give @s stick[item_model="resivour:badge"]` shows the badge texture when the pack is active.

## Updating to a new Minecraft version
Read `pack_version.resource_major/minor` from `version.json` inside the new server jar
(`unzip -p server.jar version.json`) and update `src/pack.mcmeta`.
