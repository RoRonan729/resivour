# Resivour icon font (`resivour:icons`)

One glyph per private-use codepoint, 10x10 px, ascent 8. Use in a text component:
`{"text":"\uE001","font":"resivour:icons"}` (Adventure: `Component.text("\uE001").font(Key.key("resivour", "icons"))`).

| Codepoint | Name | Picture |
|---|---|---|
| `\uE001` | me | person (head + shoulders) |
| `\uE002` | siren | 911 light (dome with rays) |
| `\uE003` | job | briefcase |
| `\uE004` | id | card with a stripe |
| `\uE005` | school | graduation cap |
| `\uE006` | city | two buildings |
| `\uE007` | bank | bank front (columns) |
| `\uE008` | police | shield badge |
| `\uE009` | medic | cross |
| `\uE00A` | judge | gavel |
| `\uE00B` | lawyer | scales |
| `\uE00C` | rpa | eye |
| `\uE00D` | map | folded map |
| `\uE00E` | back | left arrow |
| `\uE00F` | close | X |
| `\uE010` | gun | pistol silhouette, barrel right |
| `\uE011` | cuffs | two rings |
| `\uE012` | horse | horse head |
| `\uE013` | shop | shop awning |
| `\uE014` | alert | red circle with white ! |
| `\uE015` | ok | check mark |
| `\uE016` | admin | wrench |
| `\uE017` | laws | open book |
| `\uE018` | vote | ballot box |
| `\uE019` | detector | arch |
| `\uE01A` | money | coins |
| `\uE01B` | calls | handset |
| `\uE01C` | report | clipboard |
| `\uE01D` | downed | heart with a crack |
| `\uE01E` | escort | two figures |
| `\uE01F` | search | magnifier |
